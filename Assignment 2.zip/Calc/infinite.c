#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <ctype.h>

// constants
#define EOS	257
#define NUM	258

//list to store numbers
struct list {
   int digit;
   struct list *next;
};
//datatype to hold numbers
struct num {
   struct list *head;
   struct list *tail;
};

//list manipulation functions
bool isEmpty(struct list *); //passed : head
int length(struct list *, struct list *); //passed : head, tail
void insertFront(struct list **, struct list **, int); //passed : head, tail, digit
void insertBack(struct list **, struct list **, int); //passed : head, tail, digit
struct list * deleteFront(struct list **); //passed : head
void printList(FILE *, struct list **, struct list **); //passed : head, tail
void free_list(struct list **, struct list **); //passed : head, tail
struct num * my_add(struct list **, struct list **, struct list **, struct list **); //passed : head,tail for num1, and head,tail for num2
struct num * my_sub(struct list **, struct list **, struct list **, struct list **); //passed : head,tail for num1, and head,tail for num2
bool isLargerThan(struct list **, struct list **, struct list **, struct list **); //passed : old head,head,tail for num1, and old head,head,tail for num2
struct num * dup_num(struct list **, struct list **);

// prototypes 
int expr( FILE *fpRead, FILE *fpWrite );
int term( FILE *fpRead, FILE *fpWrite );
int factor( FILE *fpRead, FILE *fpWrite );
void error( char * );
int get_token( FILE *fpRead, FILE *fpWrite );
void match( int, FILE *fpRead, FILE *fpWrite );


// global communication variables
int current_token;
int current_attribute;
struct num * current_num;

/* bounded memory calculator */
int main(int argc, char * argv[])
{
	
	FILE *fpRead, *fpWrite;
        if (argc < 3) {
                fprintf(stderr,"Not enough arguments\n");
                exit(1);
        }
        if (!(fpRead = fopen(argv[1],"r"))) {
                fprintf(stderr,"Cannot open file %s\n",argv[1]);
                exit(1);
        }
        if (!(fpWrite = fopen(argv[2],"w"))) {
                fprintf(stderr,"Cannot open file %s\n",argv[2]);
                exit(1);
        }

	

	int value;
	//should be ok being allocated in factor
	current_num = (struct num*) malloc(sizeof(struct num));
	current_num->head = current_num->tail = NULL;
	while( (current_token = get_token(fpRead,fpWrite)) != EOF ){

		while ( current_token != EOS ) {
			value = expr(fpRead, fpWrite);
			fprintf( stderr, "\nValue = ");
			printList(stderr, &current_num->head, &current_num->tail);
			//fprintf( fpWrite, "%d\n", value );
			printList(fpWrite, &current_num->head, &current_num->tail);
		}
	}
	free_list(&current_num->head, &current_num->tail);
	free(current_num);
}

/* calculator */

// handles addition and subtraction
int expr(FILE *fpRead, FILE *fpWrite)
{
   int value;
   struct num *valueL2, *valueL, *res;
	value = term(fpRead, fpWrite);
   valueL = dup_num(&current_num->head, &current_num->tail);

	while (1) {
		if ( current_token == '+' ) {
			match( '+', fpRead, fpWrite);
			value += term(fpRead, fpWrite);
         valueL2 = dup_num(&current_num->head, &current_num->tail);
         current_num = my_add(&valueL->head, &valueL->tail, &valueL2->head, &valueL2->tail);
		}
		else if ( current_token == '-' ) {
			match( '-', fpRead, fpWrite);
			value -= term(fpRead, fpWrite);
         valueL2 = dup_num(&current_num->head, &current_num->tail);
         current_num = my_sub(&valueL->head, &valueL->tail, &valueL2->head, &valueL2->tail);
		}
		else break;
	}

   //free_list(&current_num->head, &current_num->tail);
   //current_num = dup_num(&res->head, &res->tail);
	return value;
}

// handles multiplication and division
int term(FILE *fpRead, FILE *fpWrite)
{
	int value = factor(fpRead, fpWrite);
	while (1) {
		if ( current_token == '*' ) {
			match( '*', fpRead, fpWrite );
			value *= factor(fpRead, fpWrite);
			fprintf(stderr, "[multiplication]");
			fprintf(fpWrite, "[multiplication]");
		}
		if ( current_token == '/' ) {
			match( '/', fpRead, fpWrite );
			value /= factor(fpRead, fpWrite);
			fprintf(stderr, "[division]");
			fprintf(fpWrite, "[division]");
		}
		else break;
	}
	return value;
}

// handles brackets and numbers
int factor(FILE *fpRead, FILE *fpWrite)
{
   int value;
	//struct num *value;
	//value = (struct num*) malloc(sizeof(struct num));
	//value->head = value->tail = NULL;

	if ( current_token == '(' ) {
		match( '(', fpRead, fpWrite );
		value = expr(fpRead, fpWrite);
		match( ')', fpRead, fpWrite );
		return value;
	}
	else if ( current_token == NUM ) {
		value = current_attribute;
		match( NUM, fpRead, fpWrite );
		//insertBack(&value->head, &value->tail, current_attribute);
		return value;
	}
	else{
		printf("Error: current_token is ");
		printf("%i", current_token);
		printf("\n");
		error( "Unexpected token in factor()" );
	}
}

/* match expected token */
void match( int expected_token, FILE *fpRead, FILE *fpWrite)
{
	if ( current_token == expected_token ) {
		current_token = get_token(fpRead, fpWrite);
	}
	else {
		error("Unexpected token in match" );
	}
}


/* get next token */
int get_token(FILE *fpRead, FILE *fpWrite)
{
	int c;		// current character from the stream
	int value;	// value of a number
	
	while ( 1 ) {
		
		c = fgetc(fpRead);
		
				
		if (c == '+' || c == '-' || c == '*' || c == '(' || c == ')' || c == '/' ) {
			fprintf( stderr, "[OP:%c]", c );
			//fprintf( fpWrite, "[OP:%c]", c );
			return c;	// return operators and brackets as is
		}
	
		else if ( c == ' ' || c == '\t' )
			continue;	// ignore spaces and tabs
			
		else if ( isdigit(c) ) {
			value = c - '0';
			while ( isdigit( c = fgetc(fpRead) )) {
				value = value * 10 + (c - '0');
            insertBack(&current_num->head, &current_num->tail, c);
			}
			ungetc( c, fpRead );
			fprintf( stderr, "[NUM:%d]", value );
			//fprintf( fpWrite, "[NUM:%d]", value );
			current_attribute = value;
			return NUM;
		}
	
		else if ( c == '\n' )
			return EOS;
		else {
			fprintf( stderr, "{%c}", c );
			error( "Unknown token" );
		}
	}
}

// error reporting function
void error( char *message )
{
	fprintf( stderr, "Error: %s\n", message );
	exit(1);
}

bool isEmpty(struct list *ptr)
{
   return ptr  == NULL;
}

int length(struct list *start, struct list *end)
{
   int length = 0;
   //if list is empty
   if(isEmpty(start)) {
      return 0;
   }
   struct list *current = start;

   while(current != end) {
      length++;
      current = current->next;
   }
   length++;

   return length;
}

//insert link at the first location
void insertFront(struct list **head, struct list **tail, int digit)
{

   //creates a link
   struct list *node = (struct list*) malloc(sizeof(struct list));
      node -> digit = digit;

   if (isEmpty(*head)) {
      *head = *tail = node;
      (*head) -> next = (*tail) -> next = NULL;
   } else {
      //point it to old first list
      node -> next = *head;

      //point first to new first list
      *head = node;
   }

}

void insertBack(struct list **head, struct list **tail, int digit)
{
   struct list *node = (struct list*) malloc(sizeof(struct list));
   node -> digit = digit;

   if (isEmpty(*head))
   {
      *head = *tail = node;
      (*head) -> next = (*tail) -> next = NULL;
   }
   else
   {
      //point it to NULL
      node -> next = NULL;

      //update old tail
      (*tail) -> next = node;
	   *tail = node;
   }
}

//delete first item
struct list * deleteFront(struct list **head)
{
   if(isEmpty((*head)->next)) {
	printf("\nDeleted value:(%d)", (*head) -> digit);
	free(head);
	*head = NULL;
      return NULL;
   }
   //save reference to first link
	struct list *old_head = *head;

   //mark next to first link as first
   *head = (*head) -> next;
	printf("\nDeleted value:(%d)", old_head -> digit);
   free(old_head);
   //return the new head
   return *head;
}

//display the list
void printList(FILE *out, struct list **head, struct list **tail)
{
   fprintf(out, "\n[ ");

   //start from the beginning
   if(!isEmpty(*head)) {
      struct list *ptr = *head;
      while(ptr != *tail) {
         if(ptr->digit != -1)
         {
            fprintf(out, "%d ", ptr -> digit);
         }
         else
         {
            fprintf(out, "- "); //for subtraction method
         }
         ptr = ptr -> next;
      }
      if(ptr->digit != -1)
      {
         fprintf(out, "%d ", ptr -> digit);
      }
      else
      {
         fprintf(out, "- ");
      }
   }
   fprintf(out, " ]\n");
}


// destructor
void free_list(struct list **head, struct list **tail)
{
   while(!isEmpty(*head)) {
      struct list *temp = deleteFront(head);
   }
    printf("\n");
}

//note carry can only ever be one
struct num * my_add(struct list **head1, struct list **tail1, struct list **head2, struct list **tail2){

    int val;
    int carry = 0;
    struct list *ptr1 = *head1;              //just creating like a temp ptr to 1st number's head
    struct list *ptr2 = *head2;              //same for above but for 2nd number
    struct list *first_tail = *tail1;        //wouldnt work unless i created a temp ptr to the tail, wouldnt let me use original
    struct list *second_tail = *tail2;       //same for above but for 2nd number
    int num1,num2;                           //values for the digit's used to calculate the value
    struct num *result;                      //where we will store our answer
    result = (struct num*) malloc(sizeof(struct num)); //not sure if this is needed, did it cause mike did
    result->head = result->tail = NULL;       //initialized

    //this loop makes sure we still have elements
    while(ptr1 != first_tail && ptr2 != second_tail){
        //for the case where num2 has more digits than num1
        if(ptr1 == first_tail && ptr2 != second_tail){
            num1 = 0;
            num2 = ptr2->digit;
            ptr2 = ptr2->next;
        }
        //for the case where num1 has more digits than num2
        else if(ptr2 == second_tail && ptr1 != first_tail){
            num2 = 0;
            num1 = ptr1->digit;
            ptr1 = ptr1->next;
        }
        else{
            num1 = ptr1 -> digit;
            num2 = ptr2 -> digit;
            ptr1 = ptr1->next;
            ptr2 = ptr2->next;
        }

        val  = num1 + num2 + carry;  //calculating val
        if(val > 9){                 //if val is greater than 9 we will have a carry of 1, and we need to mod val to get
            carry = 1;               //the least sig bit ex. say we have 5+7==12, 12 mod 10 = 2 which we would insert
            val = val % 10;
            insertBack(&result->head, &result->tail, val);
        }else{                       //case where we can just insert and not have a carry
            carry = 0;
            insertBack(&result->head, &result->tail, val);
        }
    }

    //all this stuff is basically what we did above but for the last element in tail, wouldnt let me do it in loop
    val = ptr1->digit + ptr2->digit + carry;
    if(val > 9){
        carry = 1;
        val = val % 10;
        insertBack(&result->head, &result->tail, val);
        insertBack(&result->head, &result->tail, carry);
    }else{
        carry = 0;
        insertBack(&result->head, & result->tail, val);
    }

   //printList(&result->head, &result->tail);
   return result;
}

struct num * my_sub(struct list **head1, struct list **tail1, struct list **head2, struct list **tail2){
    bool swap = false;  //needed for if 2nd number is greater than 1st number
    int carry = 0;  //basically just a suedo remainder
    struct num *result;                      
    result = (struct num*) malloc(sizeof(struct num)); 
    result->head = result->tail = NULL;

    struct list *ptr1, *ptr2, *first_tail, *second_tail;
    if(isLargerThan(head1, tail1, head2, tail2))
    {
       ptr1 = *head1; first_tail = *tail1;
       ptr2 = *head2; second_tail = *tail2;
    }
    else //if the 2nd number is larger, set the temp pointers the opposite of normal note that in swap variable
    {
       ptr2 = *head1; second_tail = *tail1;
       ptr1 = *head2; first_tail = *tail2;
       swap = true;
    }
    
    //traverses through the list
    while(ptr1 != first_tail && ptr2 != second_tail)
    {
       //if 2nd number is larger
       if(ptr1 != first_tail && ptr2 == second_tail)
       {
          insertBack(&result->head, &result->tail, ptr1->digit + carry);
          carry = 0;
          ptr1 = ptr1->next;
       }
       //if 1st number is larger
       else if(ptr1 == first_tail && ptr2 != second_tail)
       {
          insertBack(&result->head, &result->tail, ptr2->digit + carry);
          carry = 0;
          ptr2 = ptr2->next;
       }
       //if the 1st number is greater than 2nd number, subtract
       else if(ptr1->digit >= ptr2->digit)
       {
          //mainly just an edge case
          if(carry == -1 && ptr1->digit == ptr2->digit)
          {
             insertBack(&result->head, &result->tail, (ptr1->digit - ptr2->digit + carry + 10));
             ptr1 = ptr1->next;
             ptr2 = ptr2->next;
          }
          else
          {
             insertBack(&result->head, &result->tail, (ptr1->digit - ptr2->digit + carry));
             carry = 0;
             ptr1 = ptr1->next;
             ptr2 = ptr2->next;
          }
       }
       //if 2nd number is greater than 1st number, +10 then subtract, note that in carry variable 
       else
       {
          insertBack(&result->head, &result->tail, (ptr1->digit + 10 - ptr2->digit + carry));
          carry = -1;
          ptr1 = ptr1->next;
          ptr2 = ptr2->next;
       }
    }

   //same steps as while loop just done for tail
   if(ptr1->digit >= ptr2->digit)
   {
      insertBack(&result->head, &result->tail, (ptr1->digit - ptr2->digit + carry));
   }
   else
   {
      insertBack(&result->head, &result->tail, (ptr1->digit + 10 - ptr2->digit + carry));
   }
   if(swap)
   {
      insertBack(&result->head, &result->tail, -1);
   }
   return result;
}

//needed for subtraction
bool isLargerThan(struct list **head1, struct list **tail1, struct list **head2, struct list **tail2)

{
    struct list *ptr1, *ptr2, *first_tail, *second_tail;
    ptr1 = *head1;
    ptr2 = *head2; 
    first_tail = *tail1;
    second_tail = *tail2;

    while(ptr1->next != first_tail && ptr2->next != second_tail)
    {
       //if statements in while loop check for equality amoung the last digits (since they're singly linked i had to choose how many to back-check; decide 3 digits is enough)
       if( (ptr1->next->next == first_tail && ptr2->next->next == second_tail) && ptr1->next->next->digit == ptr2->next->next->digit )
       {
          if(ptr1->next->digit == ptr2->next->digit)
          {
             if(ptr1->digit >= ptr2->digit)
             {
                return true;
             }
             return false;
          }
          else if(ptr1->next->digit > ptr2->next->digit)
          {
             return true;
          }
          return false;
       }

       ptr1 = ptr1->next;
       ptr2 = ptr2->next;
    }

    ptr1 = ptr1->next;
    ptr2 = ptr2->next;

    if(ptr1 == first_tail && ptr2 == second_tail)
    {
       if(ptr1->digit > ptr2-> digit)
       {
          return true;
       }
       return false;
    }

    else if(ptr1 == first_tail)
    {
       return false;
    }
    return true;
}

struct num * dup_num(struct list **head1, struct list **tail1)
{
   struct num * res = (struct num*) malloc(sizeof(struct num));
   res->head = res->tail = NULL;
   struct list *ptr1, *ptr2;
   ptr1 = *head1;
   ptr2 = *tail1;

   while(ptr1 != ptr2)
   {
      insertBack(&res->head, &res->tail, ptr1->digit);
      ptr1 = ptr1->next;
   }
   insertBack(&res->head, &res->tail, ptr1->digit);
   return res;
}